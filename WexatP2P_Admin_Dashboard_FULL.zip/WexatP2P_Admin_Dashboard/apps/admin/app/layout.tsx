import "./globals.css";
import type { ReactNode } from "react";
export const metadata={title:"WexatP2P Admin",description:"WexatP2P administration"};
export default function Layout({children}:{children:ReactNode}){return <html lang="en"><body>{children}</body></html>}
