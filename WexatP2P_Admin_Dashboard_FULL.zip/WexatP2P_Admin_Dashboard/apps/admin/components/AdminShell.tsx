import Link from "next/link";
export default function AdminShell({children,title="Overview"}:{children:React.ReactNode,title?:string}){
 const links=[["/","Overview"],["/users","Users"],["/kyc","KYC"],["/offers","Offers"],["/trades","Trades"],["/disputes","Disputes"],["/payments","Payments"],["/fees","Fees"],["/settings","Settings"],["/audit","Audit Logs"]];
 return <div className="admin"><aside className="side"><div className="logo">Wexat<span>P2P</span></div><nav className="nav">{links.map(([href,label])=><Link key={href} href={href} className={title===label?"active":""}>{label}</Link>)}</nav><div style={{marginTop:30}} className="small">ADMIN CONTROL<br/>Server-side authorization required</div></aside><main className="main"><div className="top"><div><div className="eyebrow">WexatP2P Control Center</div><div className="title">{title}</div></div><div className="adminpill">Super Admin</div></div>{children}</main></div>
}
