const API=process.env.NEXT_PUBLIC_API_URL??"http://localhost:4000";
export async function adminGet(path:string){const r=await fetch(`${API}${path}`,{credentials:"include",cache:"no-store"});if(!r.ok)throw new Error(`API ${r.status}`);return r.json()}
export async function adminPost(path:string,body:unknown){const r=await fetch(`${API}${path}`,{method:"POST",headers:{"content-type":"application/json"},credentials:"include",body:JSON.stringify(body)});if(!r.ok)throw new Error(`API ${r.status}`);return r.json()}
