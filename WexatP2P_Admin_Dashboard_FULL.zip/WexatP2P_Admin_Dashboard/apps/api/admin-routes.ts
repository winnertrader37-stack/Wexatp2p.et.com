import { PrismaClient } from "@prisma/client";
const db=new PrismaClient();

/*
  Register these routes only behind:
  1) authenticated session
  2) adminRole RBAC
  3) CSRF protection for cookie-authenticated state changes
  4) audit logging
*/
export async function registerAdminRoutes(app:any, requireAdmin:any){
 app.get("/admin/stats",{preHandler:requireAdmin},async()=>({
   users:await db.user.count(),
   pendingKyc:await db.kycVerification.count({where:{status:"PENDING"}}),
   openTrades:await db.trade.count({where:{status:{in:["OPEN","AWAITING_PAYMENT","PAYMENT_REPORTED","DISPUTED"]}}}),
   openDisputes:await db.dispute.count({where:{status:{in:["OPEN","UNDER_REVIEW"]}}})
 }));
 app.get("/admin/users",{preHandler:requireAdmin},async(req:any)=>db.user.findMany({take:100,orderBy:{createdAt:"desc"},select:{id:true,email:true,phone:true,status:true,kycStatus:true,createdAt:true}}));
 app.get("/admin/kyc",{preHandler:requireAdmin},async()=>db.kycVerification.findMany({take:100,orderBy:{submittedAt:"desc"},include:{user:{select:{id:true,email:true,kycStatus:true}},documents:true}}));
 app.get("/admin/offers",{preHandler:requireAdmin},async()=>db.offer.findMany({take:100,orderBy:{createdAt:"desc"},include:{user:{select:{id:true,email:true,kycStatus:true}}}}));
 app.get("/admin/trades",{preHandler:requireAdmin},async()=>db.trade.findMany({take:100,orderBy:{createdAt:"desc"},include:{buyer:{select:{id:true,email:true}},seller:{select:{id:true,email:true}},payments:true}}));
 app.get("/admin/disputes",{preHandler:requireAdmin},async()=>db.dispute.findMany({take:100,orderBy:{createdAt:"desc"},include:{trade:true,openedBy:{select:{id:true,email:true}}}}));
 app.get("/admin/payments",{preHandler:requireAdmin},async()=>db.payment.findMany({take:100,orderBy:{createdAt:"desc"},include:{trade:true}}));
 app.get("/admin/audit",{preHandler:requireAdmin},async()=>db.auditEvent.findMany({take:200,orderBy:{createdAt:"desc"},include:{actor:{select:{id:true,email:true}}}}));
}
