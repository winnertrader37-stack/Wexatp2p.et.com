# WexatP2P Admin Dashboard

Production-oriented administration layer for WexatP2P.

## Modules
- Overview
- Users
- KYC review
- Offers
- Trades
- Disputes
- Payments
- Fees
- Settings
- Audit Logs

## Important
This dashboard is an administrative control layer, not a license to operate an FX/payment business. Before live ETB/USD settlement, confirm the operating model and required authorization with the National Bank of Ethiopia and use appropriately authorized providers.

The UI deliberately does not fabricate KYC or payment confirmations. Provider-backed actions must be connected to real, authenticated provider webhooks/API calls.

## Structure
apps/admin/
  page.tsx
  globals.css
  components/AdminShell.tsx
  lib/api.ts

apps/api/
  admin-routes.ts

docs/
  ADMIN_OPERATIONS.md
  PRODUCTION_SECURITY.md
