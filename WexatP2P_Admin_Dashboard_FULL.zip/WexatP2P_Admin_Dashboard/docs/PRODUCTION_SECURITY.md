# Admin Security

- Admin accounts require 2FA.
- Use separate admin domain/subdomain if possible.
- Use secure, HttpOnly, SameSite cookies.
- Add CSRF protection for cookie-authenticated mutations.
- Require re-authentication for KYC decisions, fund release, account suspension and fee changes.
- Enforce RBAC: SUPPORT, COMPLIANCE, ADMIN, SUPERADMIN.
- Rate-limit login and sensitive operations.
- Log actor, action, entity, timestamp, request ID and hashed IP; never log passwords, tokens, KYC images or payment secrets.
- KYC files belong in encrypted private object storage.
- Payment webhooks require signature verification and idempotency.
- Ledger corrections use compensating entries.
- Keep production secrets out of GitHub.
