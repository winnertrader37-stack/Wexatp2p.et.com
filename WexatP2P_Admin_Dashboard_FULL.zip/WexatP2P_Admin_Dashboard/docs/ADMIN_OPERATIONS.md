# Admin Operations

## Users
Support can view accounts and status. Suspension/reactivation must be role-protected and audited.

## KYC
Compliance reviews provider results and documents in private storage. Verification is never based on frontend state.

## Offers
Admins can pause/remove abusive offers. Do not silently rewrite historical offer/trade records.

## Trades
Support can inspect the trade state machine. Release/cancel/refund operations must be explicit, role-protected, idempotent and audited.

## Disputes
Compliance/support reviews evidence. Resolution creates an immutable audit event and compensating ledger/payment operation where applicable.

## Payments
Payment state comes from provider API/webhooks and reconciliation. Never manually mark a payment paid just because a customer sends a screenshot.

## Fees
Fee changes are versioned and audited. Historical trades keep their original fee calculation.

## Settings
Sensitive configuration is stored in environment/secret management, not database-visible plaintext.

## Audit
Audit logs must be append-only for application users. Retain according to the approved compliance policy.
